document.addEventListener('DOMContentLoaded', function() {
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const chatMessages = document.getElementById('chat-messages');

    sendButton.addEventListener('click', function() {
        const message = messageInput.value.trim();
        if (message !== '') {
            displayMessage(message, 'user');
            simulateBotResponse(message);
            messageInput.value = '';
        }
    });

    function displayMessage(message, sender) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', sender);
        messageElement.textContent = message;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight; // Scroll to bottom
    }

    function simulateBotResponse(userMessage) {
        // Simple logic for bot response
        const botResponse = generateBotResponse(userMessage);
        setTimeout(function() {
            displayMessage(botResponse, 'bot');
        }, 1000);
    }

    function generateBotResponse(userMessage) {
        // Basic chatbot responses
        const greetings = ["Hi there!", "Hello!", "Hey!"];
        const thanks = ["You're welcome!", "No problem!", "Anytime!"];
        const genericResponses = ["I'm sorry, I didn't understand that.", "Could you please repeat that?", "Let's talk about something else."];

        // Check user message and generate bot response accordingly
        if (userMessage.toLowerCase().includes('hi') || userMessage.toLowerCase().includes('hello')) {
            return greetings[Math.floor(Math.random() * greetings.length)];
        } else if (userMessage.toLowerCase().includes('thanks') || userMessage.toLowerCase().includes('thank you')) {
            return thanks[Math.floor(Math.random() * thanks.length)];
        } else {
            return genericResponses[Math.floor(Math.random() * genericResponses.length)];
        }
    }
});
